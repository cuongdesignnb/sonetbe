<template>
  <div class="webinar-editor">
    <div class="editor-header">
      <h1 class="h1">{{ isNew ? 'Tạo webinar mới' : `Sửa webinar #${webinarId}` }}</h1>
      <RouterLink class="btn btn-secondary" to="/webinars">← Quay lại</RouterLink>
    </div>

    <div v-if="loadError" class="alert alert-danger">{{ loadError }}</div>

    <form class="editor-form" @submit.prevent="save">
      <!-- Basic Info -->
      <div class="card">
        <h2 class="card-title">Thông tin cơ bản</h2>

        <label class="label">
          <span>Tiêu đề <em>*</em></span>
          <input v-model="form.title" class="input" required />
        </label>

        <label class="label">
          <span>Mô tả (HTML)</span>
          <textarea v-model="form.description" class="input textarea" rows="6" placeholder="Mô tả chi tiết webinar..."></textarea>
        </label>

        <label class="label">
          <span>Thumbnail URL</span>
          <div class="input-with-btn">
            <input v-model="form.thumbnail" class="input" placeholder="/storage/webinars/banner.jpg" />
            <button type="button" class="btn btn-secondary btn-sm" @click="pickMedia('thumbnail')">Chọn ảnh</button>
          </div>
          <img v-if="form.thumbnail" :src="form.thumbnail" class="preview-img" />
        </label>

        <div class="grid grid-2">
          <label class="label">
            <span>Trạng thái <em>*</em></span>
            <select v-model="form.status" class="input" required>
              <option value="upcoming">Sắp diễn ra</option>
              <option value="live">Đang live</option>
              <option value="completed">Đã kết thúc</option>
              <option value="cancelled">Đã hủy</option>
            </select>
          </label>
          <label class="label">
            <span>Ngày giờ diễn ra <em>*</em></span>
            <input v-model="form.scheduled_at" class="input" type="datetime-local" required />
          </label>
        </div>

        <div class="grid grid-3">
          <label class="label">
            <span>Thời lượng (phút)</span>
            <input v-model.number="form.duration_minutes" class="input" type="number" min="1" />
          </label>
          <label class="label">
            <span>Miễn phí?</span>
            <select v-model="form.is_free" class="input">
              <option :value="true">Có - Miễn phí</option>
              <option :value="false">Không - Có phí</option>
            </select>
          </label>
          <label class="label">
            <span>Giá (₫)</span>
            <input v-model.number="form.price" class="input" type="number" min="0" step="1000" :disabled="form.is_free" />
          </label>
        </div>

        <label class="label">
          <span>Số lượng tối đa</span>
          <input v-model.number="form.max_attendees" class="input" type="number" min="1" placeholder="Không giới hạn nếu để trống" />
        </label>
      </div>

      <!-- Instructor / Main Speaker -->
      <div class="card">
        <h2 class="card-title">Diễn giả chính</h2>
        <div class="grid grid-2">
          <label class="label">
            <span>Tên diễn giả <em>*</em></span>
            <input v-model="form.instructor_name" class="input" required placeholder="VD: Ms Vũ Yến" />
          </label>
          <label class="label">
            <span>Avatar URL</span>
            <div class="input-with-btn">
              <input v-model="form.instructor_avatar" class="input" placeholder="/storage/avatars/speaker.jpg" />
              <button type="button" class="btn btn-secondary btn-sm" @click="pickMedia('instructor_avatar')">Chọn ảnh</button>
            </div>
            <img v-if="form.instructor_avatar" :src="form.instructor_avatar" class="preview-img" />
          </label>
        </div>
      </div>

      <!-- Speakers -->
      <div class="card">
        <h2 class="card-title">Diễn giả khác</h2>
        <p class="card-desc">Thêm các diễn giả khách mời xuất hiện trên banner webinar</p>

        <div v-for="(speaker, idx) in form.speakers" :key="idx" class="speaker-row">
          <div class="grid grid-2">
            <label class="label">
              <span>Tên</span>
              <input v-model="speaker.name" class="input" placeholder="VD: Dr Chúc" />
            </label>
            <label class="label">
              <span>Vai trò</span>
              <input v-model="speaker.role" class="input" placeholder="VD: Chuyên gia tài chính" />
            </label>
          </div>
          <label class="label">
            <span>Avatar URL</span>
            <div class="input-with-btn">
              <input v-model="speaker.avatar" class="input" placeholder="/storage/..." />
              <button type="button" class="btn btn-secondary btn-sm" @click="pickMedia('speaker_' + idx)">Chọn ảnh</button>
            </div>
            <img v-if="speaker.avatar" :src="speaker.avatar" class="preview-img" style="max-width:80px;max-height:80px;border-radius:50%" />
          </label>
          <button type="button" class="btn-remove" @click="form.speakers.splice(idx, 1)">✕</button>
        </div>

        <button type="button" class="btn btn-secondary btn-sm" @click="addSpeaker">
          + Thêm diễn giả
        </button>
      </div>

      <!-- Benefits -->
      <div class="card">
        <h2 class="card-title">Bạn sẽ nhận được gì?</h2>
        <p class="card-desc">Danh sách lợi ích hiển thị trên trang chi tiết webinar</p>

        <div v-for="(b, idx) in form.benefits" :key="idx" class="benefit-row">
          <input v-model="form.benefits[idx]" class="input" :placeholder="'Lợi ích ' + (idx + 1)" />
          <button type="button" class="btn-remove" @click="form.benefits.splice(idx, 1)">✕</button>
        </div>

        <button type="button" class="btn btn-secondary btn-sm" @click="form.benefits.push('')">
          + Thêm lợi ích
        </button>
      </div>

      <!-- Links -->
      <div class="card">
        <h2 class="card-title">Liên kết</h2>

        <label class="label">
          <span>Zoom Link</span>
          <input v-model="form.zoom_link" class="input" placeholder="https://zoom.us/j/..." />
        </label>
        <label class="label">
          <span>Replay URL (sau khi kết thúc)</span>
          <input v-model="form.replay_url" class="input" placeholder="https://youtube.com/..." />
        </label>
      </div>

      <!-- Tags -->
      <div class="card">
        <h2 class="card-title">Tags</h2>
        <div class="tags-input">
          <span v-for="(tag, idx) in form.tags" :key="idx" class="tag-chip">
            {{ tag }}
            <button type="button" @click="form.tags.splice(idx, 1)">✕</button>
          </span>
          <input v-model="newTag" class="input input-inline" placeholder="Nhập tag rồi Enter" @keydown.enter.prevent="addTag" />
        </div>
      </div>

      <!-- Submit -->
      <div class="form-actions">
        <button type="submit" class="btn btn-primary btn-lg" :disabled="saving">
          {{ saving ? 'Đang lưu...' : (isNew ? 'Tạo webinar' : 'Lưu thay đổi') }}
        </button>
        <RouterLink class="btn btn-secondary btn-lg" to="/webinars">Hủy</RouterLink>
      </div>
    </form>

    <!-- Media Picker Modal -->
    <MediaPickerModal
      :open="mediaPicking"
      @select="onMediaPick"
      @close="mediaPicking = false"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { apiFetch } from '../lib/api'
import { useToast } from '../lib/toast'
import MediaPickerModal from '../components/MediaPickerModal.vue'

const route = useRoute()
const router = useRouter()
const toast = useToast()

const webinarId = computed(() => route.params.id as string)
const isNew = computed(() => webinarId.value === 'new')

interface Speaker {
  name: string
  role: string
  avatar: string
}

const form = ref({
  title: '',
  description: '',
  thumbnail: '',
  status: 'upcoming',
  scheduled_at: '',
  duration_minutes: null as number | null,
  is_free: true,
  price: 0,
  max_attendees: null as number | null,
  instructor_name: '',
  instructor_avatar: '',
  speakers: [] as Speaker[],
  benefits: [] as string[],
  zoom_link: '',
  replay_url: '',
  tags: [] as string[],
})

const loadError = ref('')
const saving = ref(false)
const newTag = ref('')
const mediaPicking = ref(false)
const mediaTarget = ref('')

function addSpeaker() {
  form.value.speakers.push({ name: '', role: '', avatar: '' })
}

function addTag() {
  const tag = newTag.value.trim()
  if (tag && !form.value.tags.includes(tag)) {
    form.value.tags.push(tag)
  }
  newTag.value = ''
}

function pickMedia(target: string) {
  mediaTarget.value = target
  mediaPicking.value = true
}

function onMediaPick(asset: any) {
  const url = asset?.url || asset?.path || (typeof asset === 'string' ? asset : '')
  if (!url) { mediaPicking.value = false; return }
  if (mediaTarget.value === 'thumbnail') {
    form.value.thumbnail = url
  } else if (mediaTarget.value === 'instructor_avatar') {
    form.value.instructor_avatar = url
  } else if (mediaTarget.value.startsWith('speaker_')) {
    const idx = parseInt(mediaTarget.value.replace('speaker_', ''), 10)
    if (form.value.speakers[idx]) form.value.speakers[idx].avatar = url
  }
  mediaPicking.value = false
}

async function loadWebinar() {
  if (isNew.value) return
  try {
    const data = await apiFetch<any>(`/api/admin/webinars/${webinarId.value}`)
    form.value.title = data.title || ''
    form.value.description = data.description || ''
    form.value.thumbnail = data.thumbnail || ''
    form.value.status = data.status || 'upcoming'
    form.value.scheduled_at = data.scheduled_at
      ? new Date(data.scheduled_at).toISOString().slice(0, 16)
      : ''
    form.value.duration_minutes = data.duration_minutes || null
    form.value.is_free = data.is_free ?? true
    form.value.price = Number(data.price) || 0
    form.value.max_attendees = data.max_attendees || null
    form.value.instructor_name = data.instructor_name || ''
    form.value.instructor_avatar = data.instructor_avatar || ''
    form.value.speakers = data.speakers || []
    form.value.benefits = data.benefits || []
    form.value.zoom_link = data.zoom_link || ''
    form.value.replay_url = data.replay_url || ''
    form.value.tags = data.tags || []
  } catch (e: any) {
    loadError.value = 'Không thể tải webinar: ' + (e.message || '')
  }
}

async function save() {
  saving.value = true
  try {
    const payload = {
      ...form.value,
      benefits: form.value.benefits.filter(b => b.trim()),
      speakers: form.value.speakers.filter(s => s.name.trim()),
    }

    if (isNew.value) {
      await apiFetch('/api/admin/webinars', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      toast.success('Tạo webinar thành công!')
      router.push('/webinars')
    } else {
      await apiFetch(`/api/admin/webinars/${webinarId.value}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      toast.success('Cập nhật webinar thành công!')
    }
  } catch (e: any) {
    const msg = e.data?.errors
      ? Object.values(e.data.errors).flat().join(', ')
      : (e.message || 'Lỗi không xác định')
    toast.error(msg)
  } finally {
    saving.value = false
  }
}

onMounted(loadWebinar)
</script>

<style scoped>
.webinar-editor { padding: 0; }

.editor-header {
  display: flex; justify-content: space-between; align-items: center;
  margin-bottom: 20px;
}

.card {
  background: #fff; border: 1px solid #e5e7eb; border-radius: 10px;
  padding: 24px; margin-bottom: 20px;
}
.card-title { font-size: 16px; font-weight: 700; margin: 0 0 6px; }
.card-desc { font-size: 13px; color: #6b7280; margin: 0 0 16px; }

.label { display: flex; flex-direction: column; gap: 4px; margin-bottom: 14px; }
.label span { font-size: 13px; font-weight: 600; color: #374151; }
.label em { color: #ef4444; font-style: normal; }

.grid { display: grid; gap: 16px; }
.grid-2 { grid-template-columns: 1fr 1fr; }
.grid-3 { grid-template-columns: 1fr 1fr 1fr; }

.input-with-btn { display: flex; gap: 8px; }
.input-with-btn .input { flex: 1; }

.preview-img {
  margin-top: 8px; max-width: 300px; max-height: 180px; border-radius: 8px;
  object-fit: cover; border: 1px solid #e5e7eb;
}

.textarea { resize: vertical; font-family: inherit; }

/* Speaker row */
.speaker-row {
  position: relative; border: 1px solid #e5e7eb; border-radius: 8px;
  padding: 16px; margin-bottom: 12px; background: #fafafa;
}
.speaker-row .btn-remove {
  position: absolute; top: 8px; right: 8px;
  background: none; border: none; color: #ef4444; cursor: pointer;
  font-size: 16px; font-weight: 700;
}

/* Benefit row */
.benefit-row {
  display: flex; gap: 8px; margin-bottom: 8px; align-items: center;
}
.benefit-row .input { flex: 1; }
.btn-remove {
  background: none; border: none; color: #ef4444; cursor: pointer;
  font-size: 16px; font-weight: 700; padding: 4px 8px;
}

/* Tags */
.tags-input { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }
.tag-chip {
  display: inline-flex; align-items: center; gap: 4px;
  background: #dbeafe; color: #1d4ed8; padding: 4px 10px; border-radius: 20px;
  font-size: 13px; font-weight: 600;
}
.tag-chip button {
  background: none; border: none; color: #1d4ed8; cursor: pointer;
  font-weight: 700; font-size: 14px;
}
.input-inline { flex: 1; min-width: 120px; }

/* Form actions */
.form-actions {
  display: flex; gap: 12px; margin-top: 8px; margin-bottom: 40px;
}

.btn-sm { font-size: 13px; padding: 6px 14px; }
.btn-lg { font-size: 15px; padding: 12px 32px; }
</style>
