<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Course;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class CourseSeeder extends Seeder
{
    public function run(): void
    {
        $admin = User::where('email', 'admin@example.com')->first();
        if (!$admin) {
            return;
        }

        $categories = Category::query()->whereNull('parent_id')->get();
        if ($categories->isEmpty()) {
            return;
        }

        $seedCourses = [
            ['title' => 'TikTok Growth: Từ 0 lên 100K followers', 'level' => 'beginner'],
            ['title' => 'TikTok Ads thực chiến: Tối ưu CPA', 'level' => 'advanced'],
            ['title' => 'Facebook Ads 2026: Chiến dịch chuyển đổi', 'level' => 'intermediate'],
            ['title' => 'Instagram Reels & Content Plan', 'level' => 'beginner'],
            ['title' => 'YouTube SEO + Shorts: Tăng view bền vững', 'level' => 'intermediate'],
            ['title' => 'LinkedIn B2B Lead Gen & Personal Branding', 'level' => 'advanced'],
        ];

        foreach ($seedCourses as $row) {
            $category = $categories->random();

            $sampleMarketing = [
                'promo' => [
                    'enabled' => true,
                    'text' => '🎁 ƯU ĐÃI ĐẶC BIỆT: Giảm 20% khóa học social media hôm nay!',
                ],
                'hero' => [
                    'headline' => $row['title'],
                    'subheadline' => 'Lộ trình rõ ràng, tối ưu nội dung & quảng cáo theo từng kênh',
                    'bullets' => [
                        'Framework xây dựng nội dung theo funnel',
                        'Checklist tối ưu creative, targeting, budget',
                        'Template kế hoạch đăng bài 30 ngày',
                    ],
                ],
                'workflow' => [
                    'enabled' => true,
                    'badge' => 'Social Growth Workflow',
                    'title' => 'Lộ trình 3 pha tăng trưởng kênh',
                    'subtitle' => 'Mỗi pha có checklist, KPI và lịch đăng bài rõ ràng để team bám theo.',
                    'album' => [],
                    'steps' => [
                        [
                            'title' => 'Định hình chiến lược',
                            'desc' => 'Xác định audience, insight và thông điệp cốt lõi.',
                            'tag' => 'Roadmap 30-90 ngày rõ ràng.',
                        ],
                        [
                            'title' => 'Triển khai & scale',
                            'desc' => 'Sản xuất nội dung, test creative và scale chiến dịch tốt nhất.',
                            'tag' => 'Tối ưu CPA mỗi tuần.',
                        ],
                        [
                            'title' => 'Nhân bản & bảo trì',
                            'desc' => 'Chuẩn hóa quy trình, lập lịch nội dung và báo cáo.',
                            'tag' => 'Tăng trưởng bền vững.',
                        ],
                    ],
                ],
                'stats' => [
                    ['value' => '12000+', 'label' => 'Học viên'],
                    ['value' => '4.8/5', 'label' => 'Đánh giá'],
                    ['value' => '2.7x', 'label' => 'Tăng trưởng'],
                ],
            ];

            Course::updateOrCreate(
                [
                    'title' => $row['title'],
                    'instructor_id' => $admin->id,
                ],
                [
                    'description' => 'Khóa học thực hành với dự án mẫu. Nội dung cập nhật, bài tập thực tế và hướng dẫn chi tiết.',
                    'price' => random_int(0, 1) ? random_int(199000, 1499000) : 0,
                    'thumbnail' => null,
                    'preview_video' => null,
                    'category_id' => $category->id,
                    'level' => $row['level'],
                    'duration' => random_int(120, 1200),
                    'status' => 'published',
                    'meta_description' => Str::limit('Khóa học ' . $row['title'] . ' giúp bạn nắm vững kiến thức và làm được dự án thực tế.', 160, ''),
                    'tags' => ['featured', Str::slug($category->name)],
                    'marketing' => $sampleMarketing,
                ]
            );
        }

        $levels = ['beginner', 'intermediate', 'advanced'];

        // Add a few more random courses
        for ($i = 0; $i < 12; $i++) {
            $category = $categories->random();
            $title = $category->name . ' thực chiến #' . ($i + 1);

            $marketing = [
                'promo' => [
                    'enabled' => (bool) random_int(0, 1),
                    'text' => '🎁 ƯU ĐÃI HÔM NAY: Giảm 15% cho 50 bạn đầu tiên!',
                ],
                'hero' => [
                    'headline' => $title,
                    'subheadline' => 'Học theo lộ trình - tối ưu nội dung - có checklist',
                    'bullets' => [
                        'Lộ trình rõ ràng, có roadmap',
                        'Bài tập tối ưu content/ads',
                        'Template + checklist đính kèm',
                    ],
                ],
                'workflow' => [
                    'enabled' => (bool) random_int(0, 1),
                    'badge' => 'Social Growth',
                    'title' => 'Lộ trình 3 pha tăng trưởng kênh',
                    'subtitle' => 'Chia nhỏ mục tiêu theo từng pha để dễ triển khai và theo dõi.',
                    'album' => [],
                    'steps' => [
                        [
                            'title' => 'Định hình chiến lược',
                            'desc' => 'Xác định audience, content pillars, KPI.',
                            'tag' => 'Roadmap rõ ràng.',
                        ],
                        [
                            'title' => 'Triển khai & scale',
                            'desc' => 'Test creative, scale nội dung hiệu quả.',
                            'tag' => 'Tối ưu chi phí.',
                        ],
                        [
                            'title' => 'Nhân bản & bảo trì',
                            'desc' => 'Chuẩn hóa vận hành và nhân bản mô hình.',
                            'tag' => 'Bền vững.',
                        ],
                    ],
                ],
                'stats' => [
                    ['value' => (string) random_int(800, 12000), 'label' => 'Học viên'],
                    ['value' => number_format(random_int(45, 50) / 10, 1) . '/5', 'label' => 'Đánh giá'],
                    ['value' => (string) random_int(2, 5) . 'x', 'label' => 'Tăng trưởng'],
                ],
            ];

            Course::updateOrCreate(
                [
                    'title' => $title,
                    'instructor_id' => $admin->id,
                ],
                [
                    'description' => 'Nội dung theo lộ trình, tối ưu content & ads cho kênh social media.',
                    'price' => random_int(0, 1) ? random_int(99000, 999000) : 0,
                    'thumbnail' => null,
                    'preview_video' => null,
                    'category_id' => $category->id,
                    'level' => $levels[array_rand($levels)],
                    'duration' => random_int(60, 900),
                    'status' => 'published',
                    'meta_description' => Str::limit('Khóa học ' . $title, 160, ''),
                    'tags' => [Str::slug($category->name)],
                    'marketing' => $marketing,
                ]
            );
        }
    }
}
