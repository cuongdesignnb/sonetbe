<?php

namespace App\Http\Middleware;

use App\Services\SettingsService;
use Closure;
use Illuminate\Http\Request;

class SyncRuntimeSettings
{
    public function handle(Request $request, Closure $next)
    {
        config([
            'bunnycdn.api_key' => SettingsService::get('bunnycdn.api_key', config('bunnycdn.api_key')),
            'bunnycdn.storage_zone_name' => SettingsService::get('bunnycdn.storage_zone_name', config('bunnycdn.storage_zone_name')),
            'bunnycdn.pull_zone_url' => SettingsService::get('bunnycdn.pull_zone_url', config('bunnycdn.pull_zone_url')),
            'bunnycdn.video_library_id' => SettingsService::get('bunnycdn.video_library_id', config('bunnycdn.video_library_id')),
            'bunnycdn.video_api_key' => SettingsService::get('bunnycdn.video_api_key', config('bunnycdn.video_api_key')),
            'bunnycdn.stream_hostname' => SettingsService::get('bunnycdn.stream_hostname', config('bunnycdn.stream_hostname', 'iframe.mediadelivery.net')),
            'bunnycdn.token_auth_key' => SettingsService::get('bunnycdn.token_auth_key', config('bunnycdn.token_auth_key')),
            'bunnycdn.enable_token_auth' => SettingsService::get('bunnycdn.enable_token_auth', config('bunnycdn.enable_token_auth')),
            'bunnycdn.token_ttl' => SettingsService::get('bunnycdn.token_ttl', config('bunnycdn.token_ttl', 3600)),
            'sepay.webhook_token' => SettingsService::get('sepay.webhook_token', config('sepay.webhook_token')),
            'sepay.pattern' => SettingsService::get('sepay.pattern', config('sepay.pattern', 'SE')),
            'sepay_gateway.bank_code' => SettingsService::get('sepay_gateway.bank_code', config('sepay_gateway.bank_code')),
            'sepay_gateway.account_number' => SettingsService::get('sepay_gateway.account_number', config('sepay_gateway.account_number')),
            'sepay_gateway.account_name' => SettingsService::get('sepay_gateway.account_name', config('sepay_gateway.account_name')),
        ]);

        return $next($request);
    }
}
