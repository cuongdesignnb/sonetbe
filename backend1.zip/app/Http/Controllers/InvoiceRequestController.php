<?php

namespace App\Http\Controllers;

use App\Models\InvoiceRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class InvoiceRequestController extends Controller
{
    /**
     * Store a new invoice request for a payment.
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'payment_id' => 'required|exists:course_payments,id',
            'company_name' => 'required|string|max:255',
            'tax_code' => 'required|string|max:20',
            'company_address' => 'required|string|max:500',
            'invoice_email' => 'required|email|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'message' => 'Validation failed',
                'errors' => $validator->errors(),
            ], 422);
        }

        // Check if user owns this payment
        $user = $request->user();
        $paymentExists = \App\Models\CoursePayment::where('id', $request->payment_id)
            ->where('user_id', $user->id)
            ->exists();

        if (!$paymentExists) {
            return response()->json(['message' => 'Payment not found'], 404);
        }

        // Check if invoice request already exists for this payment
        $existing = InvoiceRequest::where('payment_id', $request->payment_id)
            ->where('user_id', $user->id)
            ->first();

        if ($existing) {
            // Update existing
            $existing->update($validator->validated());
            return response()->json([
                'message' => 'Yêu cầu xuất hóa đơn đã được cập nhật',
                'invoice_request' => $existing,
            ]);
        }

        $invoiceRequest = InvoiceRequest::create([
            'user_id' => $user->id,
            'payment_id' => $request->payment_id,
            'company_name' => $request->company_name,
            'tax_code' => $request->tax_code,
            'company_address' => $request->company_address,
            'invoice_email' => $request->invoice_email,
        ]);

        return response()->json([
            'message' => 'Yêu cầu xuất hóa đơn đã được gửi',
            'invoice_request' => $invoiceRequest,
        ], 201);
    }
}
